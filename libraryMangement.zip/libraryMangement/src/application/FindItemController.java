package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import java.io.IOException;
import java.util.ArrayList;
import library.InvalidItemException;
import library.Item;

public class FindItemController {
    @FXML
    private TextField IdField;
    @FXML
    private TextField TitleField;
    @FXML
    private TextField AuthorField;
    @FXML
    private TextArea DisplayButton;

    private Stage stage;
    private Scene scene;
    private Parent root;

    

    @FXML
    public void Search(ActionEvent event) {
        String itemId = IdField.getText();

        try {
            Item foundItem = Main.library.findItem(itemId);

            if (foundItem != null) {
                DisplayButton.setText(foundItem.toString());
            } else {
                DisplayButton.setText("Item not found");
            }
        } catch (InvalidItemException e) {
            
            DisplayButton.setText("Error: " + e.getMessage());
        }
    }


    @FXML
    public void SearchTA(ActionEvent event) {
        String title = TitleField.getText();
        String author = AuthorField.getText();
        ArrayList<Item> foundItem = Main.library.findItems(title, author);

        if (foundItem != null) {
            DisplayButton.setText(foundItem.toString());
        } else {
            DisplayButton.setText("Item not found");
        }
    }
    @FXML
	public void DisplayALL(ActionEvent event) {
	 ArrayList<Item> items =Main.library.getItems();
	 String data="";

        for(Item item:items) {
        	data += item.toString() + "\n";
        }
           
        DisplayButton.setText(data);
	}

    

    @FXML
    public void Back(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

   

}
