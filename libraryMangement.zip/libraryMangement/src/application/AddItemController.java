package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

import javafx.event.ActionEvent;

import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;

public class AddItemController {
	@FXML
	private Button AddButton;
	@FXML
	private TextField Title;
	@FXML
	private TextField Author;
	@FXML
	private TextField Publish;
	@FXML
	private TextField Journal;
	@FXML
	private CheckBox BookButton;
	@FXML
	private CheckBox Moviebutton;
	@FXML
	private CheckBox PublishButton;
	@FXML
	private TextField publisherName;
	@FXML
	private TextField category;
	@FXML
	private TextArea Description;
	private Stage stage;
	 private Scene scene;
	 private Parent root;

	
	@FXML
	public void ADD(ActionEvent event) {
		if(BookButton.isSelected()) {
			String title=Title.getText();
			ArrayList<String>author=getAuthors(Author);
			String Category=category.getText();
			String pub=Publish.getText();
			int publish=Integer.parseInt(pub);
			String publisher=publisherName.getText();
			 String itemId = Main.library.addItem(title, Category, author, publish, publisher);
		        
		        
		        String authorDetails = "Authors: " + String.join(", ", author.toArray(new String[0])) + "\n";
		        String details = "Item ID: " + itemId + "\n"
		                + "Title: " + title + "\n"
		                + authorDetails
		                + "Category: " + category + "\n"
		                + "Publish Year: " + pub + "\n"
		                + "Publisher: " + publisher;

		        Description.setText(details);
			
		}
		else if(Moviebutton.isSelected()) {
			String title=Title.getText();
			ArrayList<String>author=getAuthors(Author);
			String Category=category.getText();
			String pub=Publish.getText();
			int publish=Integer.parseInt(pub);
			String itemId=Main.library.addItem(title, Category, author, publish);
			 String authorDetails = "Authors: " + String.join(", ", author.toArray(new String[0])) + "\n";
			    String details = "Item ID: " + itemId + "\n"
			            + "Title: " + title + "\n"
			            + authorDetails
			            + "Category: " + category + "\n"
			            + "Publish Year: " + pub;
			    Description.setText(details);
		}
		else if(PublishButton.isSelected()) {
			String title=Title.getText();
			ArrayList<String>author=getAuthors(Author);
			String Category=category.getText();
			String pub=Publish.getText();
			int publish=Integer.parseInt(pub);
			boolean journal=isJournal();
			String publisher=publisherName.getText();
			String itemId=Main.library.addItem(title, Category, author, publish, journal, publisher);
			String authorDetails = "Authors: " + String.join(", ", author.toArray(new String[0])) + "\n";
		    String details = "Item ID: " + itemId + "\n"
		            + "Title: " + title + "\n"
		            + authorDetails
		            + "Category: " + category + "\n"
		            + "Publish Year: " + pub + "\n"
		            + "Journal: " + (journal ? "Yes" : "No") + "\n"
		            + "Publisher: " + publisher;

		    Description.setText(details);
			
		}
		else {
			Description.setText("Select a category");
		}
		
	}
	private ArrayList<String> getAuthors(TextField author) {
		String authorsInput = author.getText();
	    String[] authorsArray = authorsInput.split(",");
	    return new ArrayList<>(Arrays.asList(authorsArray));
	}
	public boolean isJournal() {
		if(Journal.getText().equals("Y")) {
			return true;
		}
		else if(Journal.getText().equals("N")) {
			return false;
		}
		else {
			
		}
		return false;
	}
	
	@FXML
	public void Back(ActionEvent event) throws IOException{
		root = FXMLLoader.load(getClass().getResource("Scene2Lib.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	
	
}
