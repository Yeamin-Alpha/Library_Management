package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;

import javafx.scene.control.ScrollBar;

public class MemRecordController {
	@FXML
	private TextField ID;
	@FXML
	private Button SearchButton;
	@FXML
	private TextField DisplayButton;
	@FXML
	private ScrollBar Scroolbar;
	private Stage stage;
	private Scene scene;
	private Parent root;

	
	@FXML
	public void Search(ActionEvent event) {
		
	}
	
	@FXML
	public void DisplayDetails(ActionEvent event) {
		
	}
	
	@FXML
	public void Back(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Mem.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
}
