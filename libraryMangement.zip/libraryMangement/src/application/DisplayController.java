package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import library.InvalidMemberException;
import library.Member;

import java.io.IOException;
import java.util.ArrayList;

import javafx.event.ActionEvent;

public class DisplayController {
	@FXML
	private TextField ID;
	@FXML
	private Button SearchButton;
	@FXML
	private TextArea DisplayField;
	
	private Stage stage;
	 private Scene scene;
	 private Parent root;

	
	 @FXML
	 public void Search(ActionEvent event) throws InvalidMemberException {
	     String memberId = ID.getText();
	     
	     
        try {
	     if (memberId != null && !memberId.isEmpty()) {
	         Member foundMember = Main.library.findMember(memberId);
	         if (foundMember != null) {
	             DisplayField.setText(foundMember.toString());
	         } else {
	             DisplayField.setText("Member not found");
	         }
	     } else {
	         DisplayField.setText("Please enter a member ID");
	     }
        }catch(InvalidMemberException e) {
        	DisplayField.setText("Error: " + e.getMessage());
        }
	     
	 }
	     
	 

	
	 @FXML
	 public void Display(ActionEvent event) {
	     ArrayList<Member> members = Main.library.getMembers();
	     String data = "";

	     for (Member m : members) {
	         data += m.toString() + "\n";
	         DisplayField.setText(data);
	     }

	     DisplayField.setText(data);
	 }


	
	@FXML
	public void Back(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Lib.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
}
