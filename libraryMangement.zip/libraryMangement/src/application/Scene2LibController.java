package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;

public class Scene2LibController {
	@FXML
	private Button AddNewItemButton;
	@FXML
	private Button FindItemButton;
	@FXML
	private Button checkOutInButton;
	@FXML
	private Button RecordButton;
	@FXML
	private Button DisplayButton;
	@FXML
	private Button AddMemberButton;
	@FXML
	private Button BackButton;
	private Stage stage;
	private Scene scene;
	private Parent root;

	
	@FXML
	public void AddNewItem(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("AddItem.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	@FXML
	public void FindItem(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("FindItem.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	
	@FXML
	public void CheckOutIn(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("CheckOutIn.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	
	@FXML
	public void Record(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("CheckRecord.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	
	@FXML
	public void Display(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Display.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	@FXML
	public void AddMember(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("AddMember.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	
	@FXML
	public void Back(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
}
