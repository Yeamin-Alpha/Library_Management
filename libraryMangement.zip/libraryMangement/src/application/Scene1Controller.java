package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.Node;

import java.io.IOException;

import javafx.event.ActionEvent;

public class Scene1Controller {
	@FXML
	private Button MemberButton;
	@FXML
	private Button librarianButton;
	 private Stage stage;
	 private Scene scene;
	 private Parent root;

	
	@FXML
	public void Member(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Mem.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
	
	@FXML
	public void Librarian(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Lib.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}

	 
}
