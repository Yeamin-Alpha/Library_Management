package application;
	
import java.io.IOException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import library.DataHandler;
import library.Library;
import javafx.scene.Parent;
import javafx.scene.Scene;

public class Main extends Application {
	static Library library=null;
 
 @Override
 public void start(Stage stage) {
  try {
   
   Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
   Scene scene = new Scene(root);
   scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm()); 
   stage.setScene(scene);
   stage.show();
   
  } catch(Exception e) {
   e.printStackTrace();
  }
 } 

 public static void main(String[] args) {
	    try {
	        library = DataHandler.loadData();
	    } catch (ClassNotFoundException | IOException e) {
	        System.out.println("No data available");
	        library = new Library("My Library");
	        library.addMember("038", "Yeamin");
	        library.addMember("028", "Umma Salma");
	        library.addMember("030", "Niloy ranjan");

	        DataHandler.saveData(library);
	    }
	    launch(args);
	}

}