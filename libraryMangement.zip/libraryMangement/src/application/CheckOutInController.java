package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import library.CheckedOutException;
import library.InvalidItemException;
import library.InvalidMemberException;
import library.Item;
import library.Member;

import java.io.IOException;
import javafx.event.ActionEvent;

public class CheckOutInController {
	@FXML
	private TextField ID;
	@FXML
	private TextField DisplayField;
	@FXML
	private TextField IncreaseTime;
	@FXML
	private TextField IDItem;
	private Stage stage;
	 private Scene scene;
	 private Parent root;


	
	@FXML
	public void Search(ActionEvent event) {
		String memberId = ID.getText();
	     
	     
        try {
	     if (memberId != null && !memberId.isEmpty()) {
	         Member foundMember = Main.library.findMember(memberId);
	         if (foundMember != null) {
	             DisplayField.setText(foundMember.toString());
	         } else {
	             DisplayField.setText("Member not found");
	         }
	     } else {
	         DisplayField.setText("Please enter a member ID");
	     }
        }catch(InvalidMemberException e) {
        	DisplayField.setText("Error: " + e.getMessage());
        }
	     
    }
	
	@FXML
	public void SearchItem(ActionEvent event) {
		String Id = IDItem.getText();
		try {
            Item foundItem = Main.library.findItem(Id);

            if (foundItem != null) {
                DisplayField.setText(foundItem.toString());
            } else {
                DisplayField.setText("Item not found");
            }
        } catch (InvalidItemException e) {
            
            DisplayField.setText("Error: " + e.getMessage());
        }
	}
	@FXML
	public void Increase(ActionEvent event) {
		String id=IncreaseTime.getText();
		try {
			Main.library.checkIn(id);
			DisplayField.setText("Extended");
		}catch(InvalidItemException e) {
			DisplayField.setText(e.getMessage());
		}
		
	}
	
	
	
	@FXML
	public void CheckOut(ActionEvent event) throws CheckedOutException, InvalidItemException, InvalidMemberException  {
		String Id=ID.getText();
		String itemId=IDItem.getText();
		try {
			Main.library.checkOut(itemId,Id);
			DisplayField.setText("Checked out");
		}
		catch(CheckedOutException e) {
			DisplayField.setText(e.getMessage());
		}
		catch(InvalidItemException a){
			DisplayField.setText(a.getMessage());
		}
		catch(InvalidMemberException b) {
			DisplayField.setText(b.getMessage());
		}

		   
	}
	
	@FXML
	public void CheckIn(ActionEvent event) throws InvalidItemException{
		String id=IDItem.getText();
		try {
			Main.library.checkIn(id);
			DisplayField.setText("Checked IN");
		}catch(InvalidItemException e) {
			DisplayField.setText(e.getMessage());
		}
		
	}
	
	@FXML
	public void Back(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Lib.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
}
