package application;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

import javafx.event.ActionEvent;

import javafx.scene.control.TextArea;

public class AddMemberController {
	@FXML
	private Button AddButton;
	@FXML
	private TextField Name;
	@FXML
	private TextField Id;
	@FXML
	private TextArea Record;
	private Stage stage;
	 private Scene scene;
	 private Parent root;

	
	 @FXML
	 public void ADD(ActionEvent event) {
	     String name = Name.getText();
	     String id = Id.getText();

	     try {
	         Main.library.addMember(id, name);
	         Record.setText("Member added:\nID: " + id + "\nName: " + name);
	     } catch (Exception e) {
	         Record.setText("Error adding member: " + e.getMessage());
	     }
	 }

	@FXML
	public void Back(ActionEvent event) throws IOException {
		root = FXMLLoader.load(getClass().getResource("Scene2Lib.fxml"));
		  stage = (Stage)((Node)event.getSource()).getScene().getWindow();
		  scene = new Scene(root);
		  stage.setScene(scene);
		  stage.show();
	}
}
